# AGENTS.md — Pathway Planner

## Project context

A decision-support tool for caseworkers at organisations supporting trafficking survivors. The system matches survivors' skills to reachable occupations while respecting safety, legal, trauma-related, and documentation constraints. It produces ranked candidates with named, traceable reasons.

**The caseworker always decides.** This system surfaces options, explanations, and tradeoffs. It does not auto-decide, auto-apply, or auto-recommend without human review. This framing is reflected in every layer of the code and every string in the UI.

## Stack (pinned)

- Python 3.12
- `uv` — package management
- `ruff` — lint + format
- `pytest` — test runner
- `pydantic` v2 — data validation; contracts in `models/`
- `streamlit` 1.x — UI
- `plotly` 5.x — charts
- `pandas` — data loading
- `SQLite` — file-backed, encrypted PII at rest
- `cryptography` — AES-256-GCM, HMAC-SHA-256
- `anthropic` SDK — Claude API, model `claude-sonnet-4-6`
- `vcrpy` — LLM response caching for tests

## Repo layout

```
models/         contracts (FROZEN after Day 0; see models/AGENTS.md)
core/           crypto, anonymiser
db/             SQLite repository
data/raw/       teammate's source data (survivors.json, occupations.csv)
data/processed/ derived data (e.g. embeddings, if needed)
fixtures/       synthetic profiles + golden outputs
engine/         pipeline modules (internal names may use L1-L5)
app/            Streamlit UI (see app/AGENTS.md)
scripts/        utilities and git hooks
tests/          unit + integration
```

## Commands

```bash
uv sync                            # install
uv run pre-commit install          # set up hooks
uv run ruff check .                # lint
uv run pytest                      # all tests
uv run pytest -m unit              # fast tests only
uv run streamlit run app/Home.py   # local dev UI
bash scripts/install_hooks.sh      # install the commit-msg trailer stripper
```

## Boundaries

### Always

- Import shared types from `models/`. Never redefine a contract type locally.
- Anonymise before any pipeline step. The engine operates on `Ticket`, never on `Profile`.
- Mark every excluded candidate with the named `ExclusionRule` that excluded it.
- LLM calls use `temperature=0` and JSON-schema-enforced output. Validate with pydantic on parse.
- Compute confidence scores from real signal. Never hardcode.
- Compute wage ranges from the occupation row's BLS columns. Never hardcode.
- Run `ruff check` and `pytest -m unit` before declaring a task done.
- All user-facing strings live in `app/copy.py`. No bare string literals in page or component files.

### Ask first

- Any change to a schema in `models/`. Requires the `contract-change` PR label and acknowledgment from all three agent owners.
- Any new top-level dependency.
- Any new LLM prompt that is not JSON-schema-enforced.
- Any change to the encryption scheme, HMAC pepper handling, or anonymisation boundary.

### Never

- Run any git command that modifies history or remote state: `git commit`, `git push`, `git merge`, `git rebase`, `git reset`, `git tag`, `git checkout -b`, `git stash`. **The human owns all commits and pushes.** Make file edits and stop; the human reviews and commits. Read-only git commands (`git status`, `git diff`, `git log`, `git show`) are fine.
- Surface any internal pipeline terminology in the UI. The caseworker sees one coherent result. **Never write `L1`, `L2`, `L3`, `L4`, `L5`, `TOPSIS`, `MCDA`, `embedding`, `model`, `inference`, `AI says`, `AI thinks`, `confidence` (use `fit` instead), `prediction`, `pipeline`, or `engine` in any user-facing string, tab label, button, badge, tooltip, error message, or chart label.** Engine internals may use these names; the UI surface does not. See `app/copy.py` for the canonical wording.
- Add a `Co-authored-by: cursor` (or similar) trailer to any commit message. The commit-msg hook strips these; do not work around it.
- Put real survivor data anywhere. Fixtures are synthetic only, grounded in the teammate's `data/raw/survivors.json` shape.
- Let the LLM make the ranking decision. The explanation step describes the ranking the scoring step produced; it does not reorder.
- Set LLM temperature above 0 in production paths.
- Reach across agent ownership boundaries (engine into app, app into engine internals).
- Reshape the teammate's source data. The contracts in `models/__init__.py` match the raw shape; loaders parse `data/raw/` directly.

## UI design language

The visual design is non-negotiable for the demo. Surface must not drift back to vanilla Streamlit aesthetics.

- **Palette:** Vellum on white. `#FFFFFF` background, `#1B1B1F` ink, `#5C5854` slate, `#5B2B5C` plum accent. Severity: `#2D5A3D` forest, `#B5601B` sienna, `#8A1F1F` crimson. Defined in `.streamlit/config.toml` and `app/style.css`; never hardcoded elsewhere.
- **Typography:** Source Serif 4 for headings and titles, Inter for body and UI, JetBrains Mono for codes and numbers.
- **Layout:** sidebar + tabs + cards. Single page. Tabs are `Candidates / Excluded / Interventions`. Never multi-page (`pages/`) — page reloads break the deliberation feel.
- **No emoji** except in empty-state iconography. No bright primary colours. No bold/700 weight — use 400 and 500 only.
- **Score thresholds:** fit >= 0.55 renders forest, 0.35–0.55 sienna, < 0.35 crimson. Match the same thresholds the engine uses for "borderline" candidates.
- All custom HTML/CSS is rendered via `st.markdown(unsafe_allow_html=True)` consuming the shared `app/style.css`. Do not invent new CSS classes outside `style.css`.

## Workflow

- Three agents work in isolated git worktrees on Cursor-named branches.
- **All git operations are performed by the human.** Agents make file edits and surface diffs for review.
- After each deliverable, an agent runs `ruff check` and `pytest -m unit`, then stops and waits for human review.
- CI gate (on human-initiated pushes): `ruff`, `mypy models/`, `pytest` (unit + integration), `streamlit run app/Home.py --server.headless true` smoke test, and a `models/__init__.py` hash check that fails on schema drift without the `contract-change` label.
- Cache LLM responses via `vcrpy` cassettes in `tests/cassettes/`. CI does not hit the live API.

## What this is not

A job matcher. A career-search engine. An auto-recommender. It is a decision-support tool for a trained caseworker who is responsible for the recommendation. Every UI string, prompt template, and chart label reflects that.
