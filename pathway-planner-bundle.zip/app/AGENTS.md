# app/AGENTS.md — Streamlit UI

## Owner
Agent 3 (Surface).

## What this directory owns

```
app/
  Home.py              # Streamlit entry point
  style.css            # shared visual styles — ALL CSS lives here
  copy.py              # all user-facing strings
  components/
    header.py          # top bar with active-profile badge
    sidebar.py         # survivor context cards
    candidate_card.py  # expanded + collapsed candidate card
    excluded_list.py   # excluded panel, grouped by rule
    interventions_list.py  # interventions panel
    empty_state.py     # no-profile-loaded state
  plotly_theme.py      # custom plotly template (when charts are needed)
```

## Public dependency

Surface consumes only `engine.pipeline.run(ticket) -> PipelineResult`. It does not import from `engine/l*.py` directly. All types come from `models/`.

While the engine is still stubbed, `Home.py` ships with `_mock_pipeline_result()` so the UI runs end-to-end. Surface replaces that call with the real engine import once Engine ships.

## The non-negotiable design rules

These are non-negotiable for the demo. Drifting back to vanilla Streamlit aesthetics defeats the project.

### No layer language anywhere in the UI

Every string in `app/copy.py` is reviewed for tone. **Never** write `L1`, `L2`, `L3`, `L4`, `L5`, `TOPSIS`, `MCDA`, `embedding`, `model`, `inference`, `AI says`, `AI thinks`, `pipeline`, or `engine` in any user-facing string, tab label, button, badge, tooltip, error message, or chart label. The caseworker sees one coherent result.

Substitutions you should use:

| Internal name | UI surface |
|---|---|
| `topsis_score`, `confidence` | "fit" |
| `criteria_breakdown` | the bars under the card, no label needed |
| `fit_explanation` (LLM output) | just renders as prose, no label |
| `excluded_set` | "Excluded" |
| `sensitivity_report` | "Interventions" |
| `low_confidence_mappings` | "Skills to review" |
| `L4 trace`, `prompt`, `model output` | never surfaced |

### Visual rules

- **Palette:** Vellum on white. Use the CSS variables defined in `style.css`. Do not hardcode hex values in component files.
- **Typography:** Source Serif 4 for headings and card titles, Inter for body and UI, JetBrains Mono for codes and numbers. Loaded from Google Fonts in `style.css`.
- **Layout:** sidebar + tabs + cards. Single page. Never multi-page (`pages/`).
- **No emoji** except in empty-state iconography.
- **Two font weights only: 400 and 500.** No bold/700.
- **Score thresholds:** fit >= 0.55 forest, 0.35–0.55 sienna, < 0.35 crimson.

### Streamlit specifics

- All custom HTML rendered via `st.markdown(unsafe_allow_html=True)` consuming `style.css`.
- `st.set_page_config(layout="wide", initial_sidebar_state="collapsed")` — the layout uses `st.columns` for the sidebar+main split, not Streamlit's built-in sidebar.
- `st.tabs()` is fine for the three tabs.
- **Do not use `st.dataframe`, `st.metric`, `st.success`/`st.warning`/`st.error` for anything user-facing.** They carry Streamlit's default look which fights the design.
- Cache `pipeline.run(ticket)` by `ticket_id` in `st.session_state`. Do not re-run on every widget interaction.

## Hard rules

- No PII in `st.session_state` beyond `ticket_id`, `active_name` (which may be the preferred name, never the legal name unless the caseworker explicitly chose to display it), and the anonymous `Ticket`.
- Wage charts compute from `Candidate.wage_range` which the engine derives from BLS columns. Never hardcode wage values.
- Confidence values render from `CriteriaBreakdown` fields. Never invent.
- All copy lives in `copy.py`. No bare strings in components.
- The "caseworker decides" framing is in `copy.ACCOUNTABILITY` and rendered as a footer on every screen.

## Required deliverables (MVP, not stretch)

1. Profile entry form (a new page or in-place form) keyed off the `Profile` schema. Reads from `db/`.
2. Candidates tab: expanded top candidate, collapsed remaining. Already implemented in the skeleton.
3. Excluded tab: grouped by `ExclusionRule`. Already implemented.
4. Interventions tab: actionable then non-actionable. Already implemented.
5. Skills-to-review banner: present when `result.skills_to_review` is non-empty.
6. Empty state: when no profile is loaded. Already implemented.

## Test contract

- E2E test in `tests/integration/test_app_flow.py` uses `streamlit.testing.AppTest` to run each synthetic profile through the UI and asserts each panel renders without exception.
- The same test asserts no PII string from the profile (`legal_name`, `safe_phone`) appears in any rendered HTML on the Candidates / Excluded / Interventions panels.
- The same test asserts none of the banned words from the "No layer language" rule appears in any rendered HTML.
