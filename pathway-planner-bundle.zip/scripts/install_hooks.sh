#!/usr/bin/env bash
# Install repo-managed git hooks into .git/hooks.
# Run once after cloning: bash scripts/install_hooks.sh

set -e

REPO_ROOT="$(git rev-parse --show-toplevel)"
HOOKS_SRC="$REPO_ROOT/scripts/hooks"
HOOKS_DST="$REPO_ROOT/.git/hooks"

if [ ! -d "$HOOKS_SRC" ]; then
    echo "no hooks directory at $HOOKS_SRC"; exit 1
fi

for hook in "$HOOKS_SRC"/*; do
    name="$(basename "$hook")"
    cp "$hook" "$HOOKS_DST/$name"
    chmod +x "$HOOKS_DST/$name"
    echo "installed $name"
done

echo "done"
