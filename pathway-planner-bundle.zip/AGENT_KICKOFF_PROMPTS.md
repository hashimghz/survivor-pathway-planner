# Agent kickoff prompts

Paste each into a fresh Cursor worktree agent. The agent will read AGENTS.md and its scoped nested AGENTS.md automatically.

**Universal preamble** (already embedded in each prompt below):
- No git history-modifying commands. The human commits.
- No layer terminology in any user-facing string.
- No co-author trailer attribution to Cursor.

---

## Agent 1 — Bedrock (branch `agent/bedrock` or whatever Cursor names it)

```
Read AGENTS.md and models/AGENTS.md.

You are Agent 1 (Bedrock). You own core/, db/, data/, fixtures/, scripts/.
You do NOT touch models/__init__.py (frozen) or engine/ or app/.

The teammate's source data is in data/raw/survivors.json and
data/raw/occupations.csv. The contracts in models/__init__.py already match
this data shape — there is no reshape step. Pydantic validates the raw data
directly. Confirm this first by running:

  uv run python -c "
  import json
  from models import Profile
  with open('data/raw/survivors.json') as f:
      for s in json.load(f): Profile.model_validate(s)
  print('OK')
  "

Then deliver in this order:

1. core/crypto.py — AES-256-GCM encrypt/decrypt for PII fields, HMAC-SHA-256
   for ticket_id derivation. Key + pepper from env vars (.env.example shows
   the variable names). Unit tests verify round-trip.

2. core/anonymizer.py — profile_to_ticket(profile: Profile) -> Ticket. Strips
   the identity sub-object, derives ticket_id from HMAC. Unit test asserts
   no value from profile.identity appears in the resulting ticket.

3. db/repository.py — SQLite via sqlite3 stdlib. ProfileRepository with
   save/get/list. Encrypts identity fields on write, decrypts on read.

4. data/loader.py — load_survivors() returns list[Profile] from
   data/raw/survivors.json. load_occupations() returns list[Occupation] from
   data/raw/occupations.csv (the skills column contains a Python-literal
   string; parse with ast.literal_eval).

5. fixtures/golden_outputs/ — for each survivor in data/raw/survivors.json,
   produce expected anonymized ticket JSON as <profile_index>_ticket.json.
   The engine and surface agents test against these.

After each deliverable: run `ruff check` and `pytest -m unit`, then STOP and
summarize what you changed. Do NOT run git commit, git push, or any other
git history-modifying command. I own all commits.
```

---

## Agent 2 — Engine (branch `agent/engine` or whatever Cursor names it)

```
Read AGENTS.md and engine/AGENTS.md.

You are Agent 2 (Engine). You own engine/.
You do NOT touch models/, core/, db/, data/, app/.

The teammate's data ships survivor skills already mapped to O*NET ids. There
is no L1 (skill embedding) step. The pipeline is veto -> score -> explain
with a sensitivity sidecar.

Start in stub mode: implement against the contracts in models/__init__.py
and the golden fixtures Bedrock will produce. Until those land, use
app.Home._mock_pipeline_result() as your reference for the expected shape.

Deliver in this order:

1. engine/pipeline.py — public run(ticket) -> PipelineResult. Initially
   raises NotImplementedError but has the correct signature so Surface can
   import it.

2. engine/l2_veto_filter.py — one pure function per ExclusionRule
   (geography, industry, employer, documentation, work_authorization,
   criminal_record, wage_floor). Returns (filtered_occupations, excluded_set).

3. engine/l5_sensitivity.py — runs on the excluded set. Returns
   InterventionReport with actionable + non-actionable entries.

4. engine/l3_fuzzy_topsis.py — fuzzy TOPSIS over the surviving occupations.
   Map the survivor's graded_constraints to the occupation columns per the
   table in engine/AGENTS.md. Output CriteriaBreakdown with named dimensions.
   Weights load from engine/config/topsis_weights.yaml; defaults documented.

5. engine/prompts/l4_reasoner.txt — versioned prompt template. Requires
   JSON output matching the Candidate schema's narrative fields
   (fit_explanation, safe_resume_framings, risk_flags, upskill_next_step).

6. engine/l4_llm_reasoner.py — Claude API call, model claude-sonnet-4-6,
   temperature=0, JSON-schema-enforced via pydantic on parse.
   vcrpy cassettes in tests/cassettes/l4/ for deterministic tests.

7. Wire pipeline.py: veto -> (score in parallel with sensitivity) -> explain.

The wage_range on each Candidate comes directly from the occupation row's
BLS columns: p10 = wage_pct10_annual / 2080, p50 = median_wage_hourly,
p90 = wage_pct90_annual / 2080. Compute, never hardcode.

After each deliverable: run `ruff check` and `pytest -m unit`, then STOP and
summarize. Do NOT run git commit, git push, or any git history-modifying
command. I own all commits.
```

---

## Agent 3 — Surface (branch `agent/surface` or whatever Cursor names it)

```
Read AGENTS.md and app/AGENTS.md.

You are Agent 3 (Surface). You own app/, tests/integration/, README.md.
You do NOT touch models/, core/, db/, data/, engine/ internals. The only
engine import allowed is: from engine.pipeline import run.

The app skeleton is already in place. It runs out of the box with a mock
PipelineResult so you can iterate on the UI without Engine. Replace the
mock with the real engine.pipeline.run() call once Agent 2's smoke test
passes.

The non-negotiable design rules in app/AGENTS.md are LOAD-BEARING for the
demo. In particular: no layer terminology in any user-facing string, ever.

Deliver in this order:

1. app/pages/Profile.py — a Streamlit page (or in-place form) keyed off the
   Profile schema. Loads existing profiles via db.ProfileRepository and
   supports creating new ones. Field order matches survivors.json sections:
   identity, demographics, skills, constraints, legal, documents, goals.
   When the caseworker submits, anonymize and call engine.pipeline.run().

2. app/components/skill_review_modal.py — a modal that appears when the
   user clicks the "Review" button on the skills-to-review banner. Each
   uncertain skill is shown with the engine's top candidate matches; the
   caseworker confirms or overrides.

3. app/components/candidate_details_modal.py — expanded detail view when
   the user clicks "Details" on a candidate card. Shows the full nine-
   dimensional criteria breakdown (not just the six in the inline card),
   the LLM explanation in full, all safe resume framings, all risk flags,
   the wage chart at higher fidelity, and an upskill suggestion if present.

4. tests/integration/test_app_flow.py — uses streamlit.testing.AppTest.
   Runs each synthetic profile through the UI. Asserts (a) each panel
   renders, (b) no PII string from the profile appears in any rendered
   HTML, (c) none of the banned layer-language words (L1, L2, TOPSIS,
   embedding, pipeline, engine, model inference, etc.) appears anywhere
   in the rendered HTML.

5. README.md — project framing, demo instructions, 4-5 screenshots.

After each deliverable: run `ruff check` and `pytest -m unit`, then STOP
and summarize. Do NOT run git commit, git push, or any git history-
modifying command. I own all commits.
```

---

## After spawning all three

1. Set Cursor's Run Mode to "Auto-run with allow-list" and allow `ruff *`, `pytest *`, `uv *`, `python *`, `streamlit *`, `git status`, `git diff`, `git log`. Do NOT allow `git commit`, `git push`, `git merge`.
2. Pick a strong model (Claude Opus or equivalent) in each agent's window. Composer Fast will drift on the design rules.
3. Use Plan mode for the first prompt of each agent — review the plan before letting it execute.
4. Sync every ~4 hours: review the diff in each agent's Cursor session, then merge to your integration branch from your terminal (the agents won't and can't push).
