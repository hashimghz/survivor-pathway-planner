# engine/AGENTS.md — Pipeline

## Owner
Agent 2 (Engine).

## What this directory owns

Internal pipeline modules. Module names may reflect the L1-L5 architecture; the public interface does not.

Suggested layout:

```
engine/
  pipeline.py                # public interface: run(ticket) -> PipelineResult
  l2_veto_filter.py          # hard-constraint rules
  l3_fuzzy_topsis.py         # MCDA scoring on graded constraints + work context
  l4_llm_reasoner.py         # explanation, safe framings, risk flags
  l5_sensitivity.py          # relaxation analysis
  prompts/
    l4_reasoner.txt          # versioned prompt template
  tests/
```

There is **no L1 module**. The teammate's data ships skills pre-mapped to O*NET ids, so the pipeline does not embed skill text. If you want to add semantic skill expansion later, that's a separate module.

## Public interface

The only thing outside this directory may import:

```python
from engine.pipeline import run
result: PipelineResult = run(ticket)
```

Everything else is internal. No `from engine.l3_fuzzy_topsis import ...` from `app/`.

## Hard rules

- Every step is a **pure function** with a typed signature. No globals, no module-level state, no surprise I/O.
- All types imported from `models/`. Do not redefine.
- The veto step returns `tuple[list[Occupation], list[Excluded]]`. Every entry in the excluded list carries the named `ExclusionRule` that cut it.
- The scoring step scores; it never filters. A weak score lowers rank, never removes a candidate.
- The explanation step explains; it never reorders. The top-N it sees is the top-N the scoring step produced.
- The sensitivity step runs on the excluded set, not on the ranked output. It can run in parallel with scoring.
- LLM rules: `claude-sonnet-4-6`, `temperature=0`, JSON-schema-enforced output via pydantic. Malformed JSON raises `LLMSchemaError`. The prompt sees `Ticket` (anonymous) + the scored candidate's structured fields. **No PII in the prompt.** If you find yourself reaching for `Profile.identity.legal_name`, the architecture is wrong.
- Tests cache LLM responses via `vcrpy` cassettes. CI does not hit the live API.
- Score-to-severity thresholds: `>= 0.55` is high fit, `0.35 - 0.55` is mid fit, `< 0.35` is low fit. The UI uses the same cutoffs.

## Scoring against the teammate's occupation data

The occupation row carries rich work-context fields. The scoring step should map graded constraints to those columns:

| Survivor's graded constraint | Occupation column |
|---|---|
| `isolated_workplace` | `isolated_workplace` (bool) |
| `customer_facing` | `public_facing` (1-5) |
| `night_shift` | `schedule_irregularity` (1-5) |
| `requires_overnight_travel` | `schedule_irregularity` (1-5) |
| `male_dominated_team` | (no direct column; defer or research) |
| `uniformed_role` | (no direct column; defer or research) |

`violence_exposure` and `high_surveillance` are real safety signals on the occupation row — use them in scoring even though they don't have a direct graded-constraint counterpart.

## Wage range

`WageRange` is computed directly from the occupation row's BLS columns: `wage_pct10_annual / 2080`, `median_wage_hourly`, `wage_pct90_annual / 2080`. Never hardcode.

## Test contract

- Each step has a unit test that loads a golden ticket and asserts the output matches its golden file in `fixtures/golden_outputs/`.
- `pipeline.run()` has an integration test against each synthetic profile.
- Tests marked `@pytest.mark.unit` run in under 5s total — no embedding model, no LLM.
- Tests marked `@pytest.mark.integration` may use cached LLM responses but run end-to-end.
