# models/AGENTS.md — Contracts

## Status: FROZEN after Day 0

The pydantic models in this directory are the contract every agent depends on. Changes break parallel work.

## Change procedure

1. Open a PR with the `contract-change` label.
2. Describe the schema change and which layer triggered it.
3. All three agent owners (or their humans) acknowledge in PR review.
4. The CI schema-hash check is updated in the same PR.
5. Golden fixtures in `fixtures/golden_outputs/` are regenerated.

No agent edits this directory without the procedure above. If a layer needs a field that doesn't exist, surface the gap in PR review — don't patch around it.

## What lives here

| Type | Purpose | Used by |
|---|---|---|
| `Profile`, `Identity`, sub-models | Encrypted survivor record | `db/`, `core/` only |
| `Ticket` | Anonymous payload through pipeline | engine + UI |
| `Skill` | Pre-mapped O*NET skill | engine + UI |
| `Occupation`, `OccupationSkill` | Base O*NET occupation record | engine + UI |
| `Excluded` | Occupation cut by a rule | engine + UI |
| `CriteriaBreakdown`, `Candidate`, `WageRange` | Scored & explained candidate | engine -> UI |
| `Intervention`, `InterventionReport` | What would unlock more options | engine -> UI |
| `SkillToReview` | Uncertain skill flagged for caseworker | engine -> UI |
| `PipelineResult` | The single object the UI consumes | engine -> UI |

## Rules

- Pure pydantic. No business logic, no I/O, no imports from `engine/`, `app/`, `core/`, `db/`, `data/`.
- Every field has `Field(description=...)` or a clarifying docstring.
- Enum values match the teammate's raw data exactly. If a real value isn't in an enum, fail loud — never coerce.
- No optional fields without a documented reason; prefer required + sentinel values.
- Field shapes match `data/raw/survivors.json` and `data/raw/occupations.csv`. No reshape step.
- **The contracts use domain language (Candidate, Excluded, Intervention), not pipeline layer names.** This is intentional — internal modules may carry `l1_`, `l2_`, etc. names, but the data types flowing between them stay neutral.
